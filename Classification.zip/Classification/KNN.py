import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix

df = pd.read_csv("Social_Network.csv")

x = df.iloc[:,2:4].values
y = df.iloc[:,4].values

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.25,random_state=0)

sc = StandardScaler()
x_train = sc.fit_transform(x_train)
x_test = sc.transform(x_test)

classifier = KNeighborsClassifier(n_neighbors=5,metric='minkowski',p=1)
classifier.fit(x_train,y_train)

y_pred = classifier.predict(x_test)

cm = confusion_matrix(y_test,y_pred)

print("Training Score : ",classifier.score(x_train,y_train) * 100)
print("Testing Score : ",classifier.score(x_test,y_test) * 100)