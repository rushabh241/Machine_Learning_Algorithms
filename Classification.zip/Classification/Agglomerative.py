# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage

# Step 1: Load the dataset
data = pd.read_csv('Wholesale customers data.csv')

# Step 2: Preprocess the data
data = data.dropna()

# Select relevant features (assume we are using all spending columns)
features = data.iloc[:, 2:]  # Assuming the first two columns are non-spending related

# Step 3: Standardize the features
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Step 4: Compute Agglomerative Clustering
n_clusters = 5  # Adjust as needed
agg_clustering = AgglomerativeClustering(n_clusters=n_clusters)
clusters = agg_clustering.fit_predict(features_scaled)

# Add cluster labels to the original data
data['Cluster'] = clusters

# Output the first few rows of the dataset with cluster labels

# Optional: Output the distribution of clusters
cluster_distribution = data['Cluster'].value_counts()
print("\nDistribution of clusters:")
print(cluster_distribution)
