# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

# Step 1: Load the dataset
# Replace 'employee_data.csv' with your actual file path
data = pd.read_csv('employee_data.csv')

# Step 2: Preprocess the data
# Drop rows with missing values
data = data.dropna()

# Select relevant features (assuming there's an 'Income' column)
features = data[['Income']]  # Modify this based on your dataset's structure

# Step 3: Scale the features
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Step 4: Use the elbow method to determine the optimal k
wcss = []  # Within-Cluster Sum of Squares (WCSS)
k_values = range(1, 11)  # Testing k from 1 to 10

for k in k_values:
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(features_scaled)
    wcss.append(kmeans.inertia_)  # WCSS is the inertia

# Plotting the elbow method
plt.figure(figsize=(10, 6))
plt.plot(k_values, wcss, marker='o')
plt.title('Elbow Method for Optimal k')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('WCSS')
plt.xticks(k_values)
plt.grid()
plt.show()

# Step 5: Calculate Silhouette Scores for different k values
silhouette_scores = []

for k in k_values[1:]:  # Start from 2 to avoid silhouette score for k=1
    kmeans = KMeans(n_clusters=k, random_state=42)
    labels = kmeans.fit_predict(features_scaled)
    silhouette_avg = silhouette_score(features_scaled, labels)
    silhouette_scores.append(silhouette_avg)

# Plotting Silhouette Scores
plt.figure(figsize=(10, 6))
plt.plot(k_values[1:], silhouette_scores, marker='o')
plt.title('Silhouette Scores for Different k Values')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Silhouette Score')
plt.xticks(k_values[1:])
plt.grid()
plt.show()

# Step 6: Fit the K-means model with the optimal k
# Update this after analyzing elbow and silhouette score
optimal_k = 3  # Choose the optimal k based on the previous analysis
kmeans = KMeans(n_clusters=optimal_k, random_state=42)
data['Cluster'] = kmeans.fit_predict(features_scaled)

# Output the clusters
print(data[['Income', 'Cluster']].head())

# Optional: Show the distribution of clusters
plt.figure(figsize=(10, 6))
plt.scatter(features['Income'], np.zeros_like(features['Income']), c=data['Cluster'], cmap='viridis', s=50)
plt.title('K-means Clustering of Employees by Income')
plt.xlabel('Income')
plt.yticks([])  # Hide y-axis ticks
plt.grid()
plt.show()
