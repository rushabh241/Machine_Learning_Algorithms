# Import necessary libraries
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# Step 1: Load the Iris dataset
iris = load_iris()
X = iris.data  # Features: 4D (sepal length, sepal width, petal length, petal width)
y = iris.target  # Target: the species of the iris flower

# Step 2: Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 3: Reduce the 4D data to 2D using PCA
pca = PCA(n_components=2)  # Reduce to 2 components
X_pca = pca.fit_transform(X_scaled)

# Step 4: Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.2, random_state=42)

# Step 5: Train the Logistic Regression classification model
log_reg = LogisticRegression(random_state=42)
log_reg.fit(X_train, y_train)

# Step 6: Make predictions on the test set
y_pred = log_reg.predict(X_test)

# Step 7: Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

print("Accuracy:", accuracy)
print("Confusion Matrix:\n", conf_matrix)

# Step 8: Predict the class of a new flower with given measurements
# New flower measurements (sepal length, sepal width, petal length, petal width)
new_flower = np.array([[5.1, 3.5, 1.4, 0.2]])

# Standardize the new flower's data (important to use the same scaler as the training data)
new_flower_scaled = scaler.transform(new_flower)

# Reduce the new flower's dimensions using PCA (again, same PCA transformation)
new_flower_pca = pca.transform(new_flower_scaled)

# Predict the class of the new flower
predicted_class = log_reg.predict(new_flower_pca)

# Output the predicted class
print(f"Predicted class for the new flower: {iris.target_names[predicted_class][0]}")
