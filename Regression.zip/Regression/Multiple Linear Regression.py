import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.metrics import accuracy_score

df = pd.read_csv("Startup.csv")

x = df.iloc[:,:-1].values
y = df.iloc[:,4].values

labelencoder_x = LabelEncoder()
x[:, 3] = labelencoder_x.fit_transform(x[:, 3])
ct = ColumnTransformer([("Countries", OneHotEncoder(), [3])], remainder='passthrough')
x = ct.fit_transform(x)

x = x[:,1:]

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=0)

regressor = LinearRegression()
regressor.fit(x_train,y_train)

x_pred = regressor.predict(x_train)
y_pred = regressor.predict(x_test)

print("Train Score : ",regressor.score(x_train,y_train))
print("Test Score : ",regressor.score(x_test,y_test))