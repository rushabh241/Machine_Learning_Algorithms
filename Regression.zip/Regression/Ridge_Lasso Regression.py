import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso

df = pd.read_csv("Colinear.csv")

x = df.iloc[:,:-1].values
y = df.iloc[:,3].values

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=0)

regressor = LinearRegression()
regressor.fit(x_train,y_train)

x_pred = regressor.predict(x_train)
y_pred = regressor.predict(x_test)

print("Linear Train Score : ",regressor.score(x_train,y_train) * 100)
print("Linear Test Score : ",regressor.score(x_test,y_test) * 100)

rd = Ridge(alpha=2)
rd.fit(x_train,y_train)

print("Ridge Train Score : ",rd.score(x_train,y_train) * 100)
print("Ridge Test Score : ",rd.score(x_test,y_test) * 100)

ls = Lasso(alpha=2)
ls.fit(x_train,y_train)

print("Lasso Train Score : ",ls.score(x_train,y_train) * 100)
print("Lasso Test Score : ",ls.score(x_test,y_test) * 100)