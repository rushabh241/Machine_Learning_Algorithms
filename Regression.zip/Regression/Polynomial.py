import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

df = pd.read_csv("Position_Salaries.csv")

x = df.iloc[:,1:2]
y = df.iloc[:,2]

plt.scatter(x,y)

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=0)

regressor = LinearRegression()
regressor.fit(x_train,y_train)

poly_reg = PolynomialFeatures(degree=2)
x_poly = poly_reg.fit_transform(x_train)

regressor2 = LinearRegression()
regressor2.fit(x_poly,y_train)

print(df)

lin_pred = regressor.predict([[6.5]])
print("Linear Regression",lin_pred)

poly_pred = regressor2.predict(poly_reg.fit_transform([[6.5]]))
print("Polynomial Regression",poly_pred)

plt.scatter(x_train,y_train,color="Red")
plt.title("Linear Regression")
plt.plot(x_train,regressor.predict(x_train),color="Green")
plt.xlabel("Position Levels")
plt.ylabel("Salary")

plt.scatter(x_train,y_train,color="Blue")
plt.title("Polynomial Regression")
plt.plot(x_train,regressor2.predict(x_poly),color="Red")
plt.xlabel("Position Levels")
plt.ylabel("Salary")