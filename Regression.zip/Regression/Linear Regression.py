import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

df = pd.read_csv("Area_Price.csv")
print(df)

x = df.iloc[:,:-1].values
y = df.iloc[:,1].values

plt.scatter(x, y, color="Red")
plt.title("Linear Regression")
plt.xlabel("Area")
plt.ylabel("Price")

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)

regressor = LinearRegression()
regressor.fit(x_train, y_train)

x_pred = regressor.predict(x_train)
y_pred = regressor.predict(x_test)

plt.scatter(x_train, y_train, color="Blue")
plt.plot(x_train, x_pred, color="Red")
plt.title("Area vs Prices (Training Dataset)")
plt.xlabel("Area of houses")
plt.ylabel("Prices (In Rs.)")
plt.show()

plt.scatter(x_test, y_test, color="Blue")
plt.plot(x_train, x_pred, color="Red")
plt.title("Area vs Prices (Testing Dataset)")
plt.xlabel("Area of houses")
plt.ylabel("Prices (In Rs.)")
plt.show()


d = pd.read_csv("Area.csv")

p = regressor.predict(d)

d['Price'] = p

d.to_csv("Prediction.csv", index=False)
