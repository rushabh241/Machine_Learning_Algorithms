import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import BayesianRidge

df = pd.read_csv("housing.csv")

x = df.iloc[:,0:4]
y = df.iloc[:,5]

plt.plot(x,y,color="Red")

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=0)

model = BayesianRidge()
model.fit(x_train, y_train)

prediction = model.predict(x_test)

print("Lasso Train Score : ",model.score(x_train,y_train) * 100)
print("Lasso Test Score : ",model.score(x_test,y_test) * 100)