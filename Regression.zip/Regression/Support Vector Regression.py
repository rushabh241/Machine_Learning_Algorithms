import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.metrics import accuracy_score

df = pd.read_csv("Position_Salaries.csv")

x = df.iloc[:,1:2].values
y = df.iloc[:,2].values

plt.scatter(x,y)

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=0)

y = y.reshape(-1,1)

sc_x = StandardScaler()
sc_y = StandardScaler()

X = sc_x.fit_transform(x)
Y = sc_y.fit_transform(y)

regressor = SVR(kernel='rbf')
regressor.fit(X,Y.ravel())

y_pred = regressor.predict(sc_x.transform([[6.5]]))
y_pred_os = sc_y.inverse_transform(y_pred.reshape(-1,1))

print("SVR : ",y_pred_os[0][0])

model_score = regressor.score(sc_x.transform(x_test), sc_y.transform(y_test.reshape(-1, 1)))
print("SVR Model Score: ", model_score)


'''
import pandas as pd 
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR

# Load the dataset
df = pd.read_csv("Position_Salaries.csv")

# Separate the features (level) and target variable (salary)
x = df.iloc[:, 1:2].values
y = df.iloc[:, 2].values

# Plotting the data
plt.scatter(x, y)
plt.xlabel('Level')
plt.ylabel('Salary')
plt.title('Salary vs Level')
plt.show()

# Splitting the data into training and test sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)

# Reshaping y to make it a 2D array
y = y.reshape(-1, 1)

# Feature scaling
sc_x = StandardScaler()
sc_y = StandardScaler()

X = sc_x.fit_transform(x)
Y = sc_y.fit_transform(y)

# Fitting the SVR model
regressor = SVR(kernel='rbf')
regressor.fit(X, Y.ravel())

# Predicting a new result (e.g., for Level 6.5)
y_pred = regressor.predict(sc_x.transform([[6.5]]))
y_pred_original_scale = sc_y.inverse_transform(y_pred.reshape(-1, 1))

print("Predicted Salary for Level 6.5: ", y_pred_original_scale[0][0])

# Calculating the score of the model
model_score = regressor.score(sc_x.transform(x_test), sc_y.transform(y_test.reshape(-1, 1)))
print("SVR Model Score: ", model_score)'''
